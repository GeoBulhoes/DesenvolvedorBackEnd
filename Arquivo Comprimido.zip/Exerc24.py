# Solicita ao usuário que insira seu nome
nome = input("Digite seu nome: ")

# Imprime o nome na vertical
for letra in nome:
    print(letra)