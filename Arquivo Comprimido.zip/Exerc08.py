# Solicita ao usuário a temperatura em graus Celsius
celsius = float(input("Digite a temperatura em graus Celsius: "))

# Converte Celsius para Fahrenheit usando a fórmula F = (C * 9/5) + 32
fahrenheit = (celsius * 9/5) + 32

# Imprime o resultado
print("A temperatura em graus Fahrenheit é:", fahrenheit)