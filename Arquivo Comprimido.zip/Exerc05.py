# Solicita ao usuário que insira o valor do lado do quadrado
lado = float(input("Digite o valor do lado do quadrado: "))

# Calcula a área do quadrado (Área = lado²)
area = lado ** 2

# Calcula o dobro da área
dobro_area = area * 2

# Imprime os resultados
print("A área do quadrado é:", area)
print("O dobro da área do quadrado é:", dobro_area)