# Imprime os números de 1 a 20, um abaixo do outro
#for numero in range(1, 21):
#    print(numero)

# Imprime os números de 1 a 20, um ao lado do outro
for numero in range(1, 21):
    print(numero, end=" ")
