# Solicita ao usuário que insira o valor em metros
metros = float(input("Digite o valor em metros: "))

# Converte metros para centímetros
centimetros = metros * 100

# Imprime o resultado
print(metros, "metros equivalem a", centimetros, "centímetros.")