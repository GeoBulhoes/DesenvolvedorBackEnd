# Solicita ao usuário que insira seu nome
nome = input("Digite seu nome: ")

# Inverte o nome e transforma em maiúsculas
nome_invertido = nome[::-1].upper()

# Exibe o nome invertido
print("Seu nome ao contrário é:", nome_invertido)